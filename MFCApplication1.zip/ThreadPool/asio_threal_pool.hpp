#ifndef ASIO_THREAD_POOL_HPP
#define ASIO_THREAD_POOL_HPP

#include <boost/asio.hpp>
#include <boost/thread/thread_pool.hpp>
#include <functional>
#include <thread>
#include <vector>
#include <memory>



#endif
